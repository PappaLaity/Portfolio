{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}